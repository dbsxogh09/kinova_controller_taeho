#pragma once

#include <Eigen/Dense>
//CONTROLLER_CONFIG
enum CONTROLLER_SELECTOR
{
  JOINT_PD,
  JOINT_PD_FRIC,
  JOINT_NRIC,
  TASK_PD,
  TASK_PD_FRIC,
  TASK_NRIC,
  GRAVITY_COMPENSATION,
  CONTACT_FEEDBACK_MPC,
  PASSIVE_CONTACT_FEEDBACK_MPC,
};

// u = Kp * e + Kd * de
struct JOINT_PD_Gains
{
  Eigen::MatrixXd Kp; // Proportional gain
  Eigen::MatrixXd Kd; // Derivative gain
};

struct JOINT_NRIC_Gains
{
  Eigen::MatrixXd k1;
  Eigen::MatrixXd k2;
  Eigen::MatrixXd K;
  Eigen::MatrixXd gamma;
  Eigen::MatrixXd reflected_inertia;
  Eigen::MatrixXd Kp; // Proportional gain
  Eigen::MatrixXd Ki; // Integral gain
};

struct TASK_PD_Gains
{
  Eigen::MatrixXd Kp; // Proportional gain
  Eigen::MatrixXd Kd; // Derivative gain
};

struct TASK_NIRC_Gains
{
  Eigen::MatrixXd k1;
  Eigen::MatrixXd k2;
  Eigen::MatrixXd K;
  Eigen::MatrixXd gamma;
  Eigen::MatrixXd reflected_inertia;
  Eigen::MatrixXd Kp; // Proportional gain
  Eigen::MatrixXd Ki; // Integral gain
};

struct EnergyTankConfig
{
  double initial_energy;
  double max_energy;
  double min_energy;
  double mpc_run_out_time;
  Eigen::MatrixXd Kd;
};

//CONTROLLER_CONFIG
struct JOINT_FRIC_Gains
{
  Eigen::MatrixXd Kp;
  Eigen::MatrixXd Kd;
  Eigen::MatrixXd motor_inertia_matrix;
  Eigen::MatrixXd joint_stiffness_matrix;
  Eigen::MatrixXd L; 
  Eigen::MatrixXd Lp; 
};