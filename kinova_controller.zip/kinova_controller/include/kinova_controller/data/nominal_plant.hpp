#pragma once

#include <Eigen/Dense>

struct NominalPlant
{
    Eigen::VectorXd ddtheta;
    Eigen::VectorXd dtheta;
    Eigen::VectorXd theta;

    Eigen::VectorXd q;
    Eigen::VectorXd dq;
    Eigen::VectorXd ddq;
    Eigen::VectorXd integral_e_RN;

    Eigen::VectorXd friction;
};