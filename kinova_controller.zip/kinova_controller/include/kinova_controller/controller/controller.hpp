#pragma once

#include <pinocchio/parsers/urdf.hpp>
#include <pinocchio/multibody/model.hpp>
#include <pinocchio/multibody/fwd.hpp>
#include <Eigen/Core>
#include <Eigen/Geometry>
#include <iostream>
#include <fstream>
#include <Eigen/Dense>
#include <chrono>
#include <thread>
#include <rclcpp/rclcpp.hpp>

#include "kinova_controller/data/robot_state.hpp"
#include "kinova_controller/data/nominal_plant.hpp"
#include "kinova_controller/data/energy_tank_data.hpp"
#include "kinova_controller/energy_tank/energy_tank.hpp"

#include <yaml-cpp/yaml.h>
#include "kinova_controller/data/controller_state.hpp"
#include "kinova_controller/data/opt_data.hpp"
#include "kinova_controller/controller/controller_gain.hpp"
#include "kinova_controller/filter/lpf.hpp"

#include "controller_interface_msgs/msg/controller_config.hpp"


class Controller
{
    public:
    int loop_index_=0;
    Controller();

    void assign_robot_state(std::shared_ptr<RobotState> robot_state_arg);
    void assign_opt_data(std::shared_ptr<OptData> opt_data_arg);
    void init();
    CONTROLLER_SELECTOR select(const std::string & controller_type);
    Eigen::VectorXd get_control_input(const int& selector);
    EnergyTankData get_tank_data(){return energy_tank_data;}
    EnergyTank get_tank(){return energy_tank;}
    ControllerGain get_controller_gain(){return controller_gain;}
    void update_controller_gain(const YAML::Node& node);


    private:
    std::shared_ptr<RobotState> robot_state;
    std::shared_ptr<OptData> opt_data;
    ControllerGain controller_gain;
    int nq, nv, nu;
    double dt;
    CONTROLLER_SELECTOR selector_prev;

    //for lugre friction
    Eigen::VectorXd z_;

    //for NRIC
    NominalPlant nominal_plant;

    //for energy tank
    EnergyTankData energy_tank_data;
    EnergyTank energy_tank;

    //for flexible joint robot parameter
    Eigen::MatrixXd joint_stiffness_matrix_;
    Eigen::MatrixXd rotor_inertia_matrix_;

    //for low-pass filtering optimal control input
    LPF lpf_opt_u;
    
    //*****************************Controller**********************************//

    // Eigen::VectorXd quasi_static_estimate_q();

    // Eigen::VectorXd lugre_friction();

    // Eigen::VectorXd friction_observer_PD(, Eigen::VectorXd control_motor_torque);

    bool init_PD_joint_controller();
    Eigen::VectorXd PD_joint_controller();

    bool init_PD_task_controller();
    Eigen::VectorXd PD_task_controller();

    // Eigen::VectorXd PD_controller_AS_GC();

    // Eigen::VectorXd PD_controller_AS_GC_task_space();

    // Eigen::MatrixXd Null_space_projection();

    bool init_NRIC_joint_controller();
    Eigen::VectorXd NRIC_joint_controller();

    bool init_NRIC_task_controller();
    Eigen::VectorXd NRIC_task_controller();

    //CONCTROLLER_CONFIG
    bool init_FRIC_joint_controller();
    Eigen::VectorXd FRIC_joint_controller();

    bool init_gravity_compensation();
    Eigen::VectorXd gravity_compensation();

    bool init_contact_feedback_mpc();
    Eigen::VectorXd contact_feedback_mpc();

    bool init_passive_contact_feedback_mpc();
    Eigen::VectorXd passive_contact_feedback_mpc();

    //*************************************************************************//
};