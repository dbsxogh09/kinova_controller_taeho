# kinova_controller
ROS2 foxy version
