#include <kinova_controller/controller/controller.hpp>

Controller::Controller()
{   
}   

void Controller::assign_robot_state(std::shared_ptr<RobotState> robot_state_arg)
{
    robot_state = robot_state_arg;
}

void Controller::assign_opt_data(std::shared_ptr<OptData> opt_data_arg)
{
    opt_data = opt_data_arg;
}

void Controller::init()
{   
    nq = robot_state->nq;
    nv = robot_state->nv;
    nu = robot_state->nu;
    dt = robot_state->dt;
    //for lugre friction
    z_.resize(nv); z_.setZero(); 
    joint_stiffness_matrix_.resize(nv,nv); joint_stiffness_matrix_.setZero();
    rotor_inertia_matrix_.resize(nv,nv); rotor_inertia_matrix_.setZero();

    YAML::Node config = robot_state->get_config();
    controller_gain.init(config);

    try
    {
        std::vector<double> joint_stiffness_vec = config["joint_stiffness"].as<std::vector<double>>();
        std::vector<double> rotor_inertia_vec = config["rotor_inertia"].as<std::vector<double>>();
        joint_stiffness_matrix_.diagonal() = Eigen::Map<Eigen::VectorXd>(joint_stiffness_vec.data(), joint_stiffness_vec.size());
        rotor_inertia_matrix_.diagonal() = Eigen::Map<Eigen::VectorXd>(rotor_inertia_vec.data(), rotor_inertia_vec.size());
    }
    catch(YAML::Exception &e)
    {   
        std::cout<<"ERROR: joint stiffness or rotor intertia are poorly defined in the yaml file"<<std::endl;
        std::cout<<"YAML Exception : "<<e.what()<<std::endl;
    }
    
    // initialize desired value
    robot_state->q_d = robot_state->q;
    robot_state->dq_d = Eigen::VectorXd::Zero(robot_state->nv);
    robot_state->ddq_d = Eigen::VectorXd::Zero(robot_state->nv);
    robot_state->dtheta = robot_state->q;

    //Initialize nominal plant
    nominal_plant.q.resize(nq); nominal_plant.q.setZero();
    nominal_plant.q = robot_state->q;
    nominal_plant.dq.resize(nv); nominal_plant.dq.setZero();
    nominal_plant.ddq.resize(nv); nominal_plant.ddq.setZero();
    nominal_plant.theta.resize(nq); nominal_plant.theta.setZero();
    nominal_plant.theta = robot_state->theta;
    nominal_plant.dtheta.resize(nv); nominal_plant.dtheta.setZero();
    nominal_plant.friction.resize(nv); nominal_plant.friction.setZero();
    nominal_plant.integral_e_RN.resize(nv); nominal_plant.integral_e_RN.setZero();
}

void Controller::update_controller_gain(const YAML::Node& node)
{
    controller_gain.init(node);
}
//CONTROLLER_CONFIG
CONTROLLER_SELECTOR Controller::select(const std::string & controller_type)
{   
    CONTROLLER_SELECTOR controller_selector;
    if(controller_type == "JOINT_NRIC")
    {   
        std::cout<<"JOINT_NRIC controller is selected"<<std::endl;
        if(this->init_NRIC_joint_controller())
        {
            controller_selector = CONTROLLER_SELECTOR::JOINT_NRIC;
            selector_prev = controller_selector;
        }
        else
        {
            std::cout<<"JOINT_NRIC controller initialization failed"<<std::endl;
            controller_selector = selector_prev;
        }
    }
    else if(controller_type == "JOINT_PD")
    {   
        std::cout<<"JOINT_PD controller is selected"<<std::endl;
        if(this->init_PD_joint_controller())
        {
            controller_selector = CONTROLLER_SELECTOR::JOINT_PD;
            selector_prev = controller_selector;
        }
        else
        {
            std::cout<<"JOINT_PD controller initialization failed"<<std::endl;
            controller_selector = selector_prev;
        }
    }
    else if(controller_type == "TASK_NRIC")
    {   
        std::cout<<"TASK_NRIC controller is selected"<<std::endl;
        if(this->init_NRIC_task_controller())
        {
            controller_selector = CONTROLLER_SELECTOR::TASK_NRIC;
            selector_prev = controller_selector;
        }
        else
        {
            std::cout<<"TASK_NRIC controller initialization failed"<<std::endl;
            controller_selector = selector_prev;
        }
    }
    else if(controller_type == "TASK_PD")
    {   
        std::cout<<"TASK_PD controller is selected"<<std::endl;
        if(this->init_PD_task_controller())
        {
            controller_selector = CONTROLLER_SELECTOR::TASK_PD;
            selector_prev = controller_selector;
        }
        else
        {
            std::cout<<"TASK_PD controller initialization failed"<<std::endl;
            controller_selector = selector_prev;
        }
    }
    else if(controller_type == "GRAVITY_COMPENSATION")
    {   
        std::cout<<"GRAVITY_COMPENSATION controller is selected"<<std::endl;
        if(this->init_gravity_compensation())
        {
            controller_selector = CONTROLLER_SELECTOR::GRAVITY_COMPENSATION;
            selector_prev = controller_selector;
        }
        else
        {
            std::cout<<"GRAVITY_COMPENSATION controller initialization failed"<<std::endl;
            controller_selector = selector_prev;
        }

    }
    else if(controller_type == "CONTACT_FEEDBACK_MPC")
    {   
        std::cout<<"CONTACT_FEEDBACK_MPC controller is selected"<<std::endl;
        if(this->init_contact_feedback_mpc())
        {
            controller_selector = CONTROLLER_SELECTOR::CONTACT_FEEDBACK_MPC;
            selector_prev = controller_selector;
        }
        else
        {
            std::cout<<"CONTACT_FEEDBACK_MPC controller initialization failed"<<std::endl;
            controller_selector = selector_prev;
        }
    }
    else if(controller_type == "PASSIVE_CONTACT_FEEDBACK_MPC")
    {   
        std::cout<<"PASSIVE_CONTACT_FEEDBACK_MPC controller is selected"<<std::endl;
        if(this->init_passive_contact_feedback_mpc())
        {
            controller_selector = CONTROLLER_SELECTOR::PASSIVE_CONTACT_FEEDBACK_MPC;
            selector_prev = controller_selector;
        }
        else
        {
            std::cout<<"PASSIVE_CONTACT_FEEDBACK_MPC controller initialization failed"<<std::endl;
            controller_selector = selector_prev;
        }
    }
    else if(controller_type == "JOINT_PD_FRIC")
    {   
        std::cout<<"JOINT_PD_FRIC controller is selected"<<std::endl;
        if(this->init_FRIC_joint_controller())
        {
            controller_selector = CONTROLLER_SELECTOR::JOINT_PD_FRIC;
            selector_prev = controller_selector;
        }
        else
        {
            std::cout<<"JOINT_PD_FRIC controller initialization failed"<<std::endl;
            controller_selector = selector_prev;
        }
    }
    else
    {   
        std::cout<<"controller type is not valid"<<std::endl;
        controller_selector = selector_prev;
    }
    
    return controller_selector;
}

//CONTROLLER_CONFIG
Eigen::VectorXd Controller::get_control_input(const int& selector)
{   
    Eigen::VectorXd u;
    switch (selector)
    {
    case CONTROLLER_SELECTOR::JOINT_PD:
        u=this->PD_joint_controller();
        break;
    case CONTROLLER_SELECTOR::JOINT_PD_FRIC:
        u=this->FRIC_joint_controller();
        break;

    case CONTROLLER_SELECTOR::TASK_PD:
        u=this->PD_task_controller();
        break;

    case CONTROLLER_SELECTOR::TASK_PD_FRIC:
        // u=this->PD_controller_AS_GC_task_space(robot_state);
        break;

    case CONTROLLER_SELECTOR::JOINT_NRIC:
        u = this->NRIC_joint_controller();
        break;

    case CONTROLLER_SELECTOR::TASK_NRIC:
        u = this->NRIC_task_controller();
        break;

    case CONTROLLER_SELECTOR::GRAVITY_COMPENSATION:
        u = this->gravity_compensation();
        break;

    case CONTROLLER_SELECTOR::CONTACT_FEEDBACK_MPC:
        u = this->contact_feedback_mpc();
        break;
    
    case CONTROLLER_SELECTOR::PASSIVE_CONTACT_FEEDBACK_MPC:
        u = this->passive_contact_feedback_mpc();
        break;
    
    default:
        break;
    }

    return u;
}

bool Controller::init_PD_joint_controller()
{
    // initialize desired value
    robot_state->q_d = robot_state->q;
    robot_state->dq_d = Eigen::VectorXd::Zero(robot_state->nv);
    robot_state->ddq_d = Eigen::VectorXd::Zero(robot_state->nv);

    return true;
}

Eigen::VectorXd Controller::PD_joint_controller()
{
    //Gain
    const JOINT_PD_Gains &gain = controller_gain.get_JOINT_PD_Gains();

    Eigen::VectorXd control_motor_torque;

    if(robot_state->is_rigid)
    {   
        Eigen::VectorXd gravity_compensation_torque(nv);
        gravity_compensation_torque = robot_state->get_gravity(robot_state->q_d);
        control_motor_torque = -gain.Kp*(robot_state->difference(robot_state->q_d, robot_state->q))-gain.Kd*(robot_state->dq - robot_state->dq_d)+gravity_compensation_torque;
    }
    else
    {
        Eigen::VectorXd gravity_compensation_torque(nv), theta_des(nq);
        gravity_compensation_torque = robot_state->get_gravity(robot_state->q_d);
        // std::cout<<"gravity_compensation_torque : \n"<<gravity_compensation_torque.transpose()<<std::endl;
        theta_des = robot_state->integrate(robot_state->q_d, joint_stiffness_matrix_.inverse()*gravity_compensation_torque, 1);
        control_motor_torque = -gain.Kp*(robot_state->theta-theta_des)-gain.Kd*(robot_state->dtheta - robot_state->dq_d)+gravity_compensation_torque;
    }
    
    return control_motor_torque;
}

bool Controller::init_NRIC_joint_controller()
{
    // initialize desired value
    robot_state->q_d = robot_state->q;
    robot_state->dq_d = Eigen::VectorXd::Zero(robot_state->nv);
    robot_state->ddq_d = Eigen::VectorXd::Zero(robot_state->nv);

    // initialize nominal plant
    nominal_plant.q.resize(nq); nominal_plant.q.setZero();
    nominal_plant.q = robot_state->q;
    nominal_plant.dq.resize(nv); nominal_plant.dq.setZero();
    nominal_plant.ddq.resize(nv); nominal_plant.ddq.setZero();

    return true;
}

Eigen::VectorXd Controller::NRIC_joint_controller()
{   
    const JOINT_NRIC_Gains &gain = controller_gain.get_JOINT_NRIC_Gains();

    Eigen::MatrixXd M = robot_state->get_mass(robot_state->q) + gain.reflected_inertia;
    Eigen::MatrixXd C = robot_state->get_coriolis(robot_state->q,robot_state->dq);
    Eigen::VectorXd g = robot_state->get_gravity(robot_state->q);

    Eigen::MatrixXd nominal_M = robot_state->get_mass(nominal_plant.q) + gain.reflected_inertia;
    Eigen::MatrixXd nominal_C = robot_state->get_coriolis(nominal_plant.q,nominal_plant.dq);
    Eigen::VectorXd nominal_g = robot_state->get_gravity(nominal_plant.q);

    Eigen::VectorXd tauC(nv); tauC.setZero();
    Eigen::VectorXd tauA(nv); tauA.setZero();
    Eigen::VectorXd tauGrav(nv); tauGrav.setZero();
    Eigen::VectorXd tauPD(nv); tauPD.setZero();

    /// ****** NRIC
    
    // Eigen::VectorXd e_DN = robot_state.q_d - nominal_plant.q;
    Eigen::VectorXd e_DN = robot_state->difference(nominal_plant.q, robot_state->q_d);
    Eigen::VectorXd edot_DN = robot_state->dq_d - nominal_plant.dq;
    Eigen::VectorXd e_RN = robot_state->difference(nominal_plant.q, robot_state->q);
    Eigen::VectorXd edot_RN = robot_state->dq - nominal_plant.dq;

    tauC = nominal_M*(robot_state->ddq_d + gain.k1 * edot_DN + gain.k2 * e_DN) + nominal_C*nominal_plant.dq + nominal_g;

    nominal_plant.ddq = nominal_M.inverse() * (tauC - nominal_C*nominal_plant.dq - nominal_g);
    nominal_plant.dq += nominal_plant.ddq * dt;
    nominal_plant.q = robot_state->integrate(nominal_plant.q, nominal_plant.dq, dt);

    Eigen::VectorXd s_vector = (edot_RN + gain.Kp * e_RN + gain.Ki * nominal_plant.integral_e_RN);
    nominal_plant.integral_e_RN += e_RN * dt;

    
    tauA = -(gain.K + gain.gamma) * s_vector;

    // Eigen::VectorXd e_RD = robot_state.q - robot_state.q_d;
    Eigen::VectorXd e_RD = robot_state->difference(robot_state->q_d, robot_state->q);

    return tauA + tauC;
}

bool Controller::init_PD_task_controller()
{
    // initialize desired value
    robot_state->q_d = robot_state->q;
    robot_state->dq_d = Eigen::VectorXd::Zero(robot_state->nv);
    robot_state->ddq_d = Eigen::VectorXd::Zero(robot_state->nv);

    return true;
}

Eigen::VectorXd Controller::PD_task_controller()
{   
    //gain
    const TASK_PD_Gains & gain = controller_gain.get_TASK_PD_Gains();

    // task space error
    pinocchio::SE3 dhtm(robot_state->get_ee_pose(robot_state->q_d, "end_effector").matrix());
    pinocchio::SE3 htm(robot_state->get_ee_pose(robot_state->q, "end_effector").matrix());
    pinocchio::SE3 rhtm = dhtm.inverse() * htm;
    Eigen::Matrix<double, 6, 1> error_task = -pinocchio::log6(rhtm).toVector();

    // projection onto joint space
    auto nominalJ = robot_state->get_ee_jacobian_b(robot_state->q, "end_effector");
    Eigen::VectorXd e_task = gain.Kp * error_task;
    Eigen::VectorXd edot_task = gain.Kd * nominalJ * robot_state->dq;

    Eigen::VectorXd g = robot_state->get_gravity(robot_state->q);

    Eigen::VectorXd u = nominalJ.transpose()*(-edot_task + e_task) + g;

    return u;
}

bool Controller::init_NRIC_task_controller()
{
    // initialize desired value
    robot_state->q_d = robot_state->q;
    robot_state->dq_d = Eigen::VectorXd::Zero(robot_state->nv);
    robot_state->ddq_d = Eigen::VectorXd::Zero(robot_state->nv);

    // initialize nominal plant
    nominal_plant.q.resize(nq); nominal_plant.q.setZero();
    nominal_plant.q = robot_state->q;
    nominal_plant.dq.resize(nv); nominal_plant.dq.setZero();
    nominal_plant.ddq.resize(nv); nominal_plant.ddq.setZero();

    return true;
}

Eigen::VectorXd Controller::NRIC_task_controller()
{   
    //gain
    const TASK_NIRC_Gains & gain = controller_gain.get_TASK_NIRC_Gains();

    Eigen::MatrixXd M = robot_state->get_mass(robot_state->q) + gain.reflected_inertia;
    Eigen::MatrixXd C = robot_state->get_coriolis(robot_state->q,robot_state->dq);
    Eigen::VectorXd g = robot_state->get_gravity(robot_state->q);

    Eigen::MatrixXd nominal_M = robot_state->get_mass(nominal_plant.q) + gain.reflected_inertia;
    Eigen::MatrixXd nominal_C = robot_state->get_coriolis(nominal_plant.q,nominal_plant.dq);
    Eigen::VectorXd nominal_g = robot_state->get_gravity(nominal_plant.q);

    Eigen::VectorXd tauC(nv); tauC.setZero();
    Eigen::VectorXd tauA(nv); tauA.setZero();
    Eigen::VectorXd tauGrav(nv); tauGrav.setZero();
    Eigen::VectorXd tauPD(nv); tauPD.setZero();

    /// ****** NRIC
    pinocchio::SE3 dhtm(robot_state->get_ee_pose(robot_state->q_d, "end_effector").matrix());
    pinocchio::SE3 nominal_htm(robot_state->get_ee_pose(nominal_plant.q, "end_effector").matrix());
    pinocchio::SE3 rhtm = dhtm.inverse() * nominal_htm;
    Eigen::Matrix<double, 6, 1> error_task = -pinocchio::log6(rhtm).toVector();

    auto nominalJ = robot_state->get_ee_jacobian_b(nominal_plant.q, "end_effector");
    Eigen::VectorXd e_task_DN = gain.k2 * error_task;
    Eigen::VectorXd edot_task_DN = gain.k1 * nominalJ * nominal_plant.dq;

    Eigen::VectorXd temp = robot_state->ddq_d + nominalJ.transpose()*(-edot_task_DN + e_task_DN);
    tauC = nominal_M*temp + nominal_C*nominal_plant.dq + nominal_g;

    nominal_plant.ddq = nominal_M.inverse() * (tauC - nominal_C*nominal_plant.dq - nominal_g);
    nominal_plant.dq += nominal_plant.ddq * dt;
    nominal_plant.q = robot_state->integrate(nominal_plant.q, nominal_plant.dq, dt);

    Eigen::VectorXd e_RN = robot_state->difference(nominal_plant.q, robot_state->q);
    Eigen::VectorXd edot_RN = robot_state->dq - nominal_plant.dq;

    Eigen::VectorXd s_vector = (edot_RN + gain.Kp * e_RN + gain.Ki * nominal_plant.integral_e_RN);
    nominal_plant.integral_e_RN += e_RN * dt;

    tauA = -(gain.K + gain.gamma) * s_vector;


    pinocchio::SE3 real_htm(robot_state->get_ee_pose(robot_state->q, "end_effector").matrix());
    pinocchio::SE3 rdhtm = dhtm.inverse() * real_htm;
    Eigen::Matrix<double, 6, 1> e_RD = -pinocchio::log6(rdhtm).toVector();
    
    return tauA + tauC;
}

//CONTROLLER_CONFIG
bool Controller::init_FRIC_joint_controller()
{
    // initialize desired value
    robot_state->q_d = robot_state->q;
    robot_state->dq_d = Eigen::VectorXd::Zero(robot_state->nv);

    // initialize nominal plant
    nominal_plant.theta.resize(nq); nominal_plant.theta.setZero();
    nominal_plant.theta = robot_state->theta;
    nominal_plant.dtheta.resize(nv); nominal_plant.dtheta.setZero();
    nominal_plant.ddtheta.resize(nv); nominal_plant.ddtheta.setZero();
    return true;
}

Eigen::VectorXd Controller::FRIC_joint_controller()
{
    const JOINT_FRIC_Gains &gain = controller_gain.get_JOINT_FRIC_Gains();

    Eigen::VectorXd g = robot_state->get_gravity(robot_state->q_d); // gravity compensation torque w.r.t desired q
    Eigen::VectorXd theta_d = robot_state->q_d + (gain.joint_stiffness_matrix).inverse() * g; // desired theta   

    Eigen::VectorXd tauC(nu); tauC.setZero();
    Eigen::VectorXd est_tauf(nu); est_tauf.setZero();
    Eigen::VectorXd tauf(nu); tauf.setZero();
    Eigen::VectorXd u(nu); u.setZero();

    Eigen::VectorXd e_DN = robot_state->difference(nominal_plant.theta, theta_d);
    Eigen::VectorXd edot_DN = robot_state->dq_d - nominal_plant.dtheta;
    Eigen::VectorXd e_NR = robot_state->difference(nominal_plant.theta, robot_state->theta);
    Eigen::VectorXd edot_NR = robot_state->dtheta - nominal_plant.dtheta;

    tauC = gain.Kp*e_DN + gain.Kd*edot_DN + g; // motor PD controller

    nominal_plant.ddtheta = (gain.motor_inertia_matrix).inverse() * (tauC - robot_state->tau_J);
    nominal_plant.dtheta += nominal_plant.ddtheta * dt;
    nominal_plant.theta = robot_state->integrate(nominal_plant.theta, nominal_plant.dtheta, dt);

    est_tauf =  (gain.L) * (gain.motor_inertia_matrix) * (edot_NR + gain.Lp*e_NR); // friction compensation torque

    u = tauC - est_tauf;

    if(robot_state->is_simulation)
    {   
        // lugre friction modeling 
        double sigma_0, sigma_1, sigma_2, Fc, Fs, vs;
        sigma_0 = 100; sigma_1 = sqrt(sigma_0); sigma_2 = 0.4; Fc = 5; Fs = 7.5; vs = 0.001;
        
        Eigen::VectorXd r(nv), g_v(nv), z_dot(nv); 
        r.setZero(); g_v.setZero(); z_dot.setZero(); 
        r = -(robot_state->dtheta/vs) * (robot_state->dtheta/vs);

        for(int i=0; i<nv; i++)
            {
                g_v(i) = Fc + (Fs - Fc) * exp(r(i));   
                z_dot(i) = robot_state->dtheta(i) - sigma_0 * fabs(robot_state->dtheta(i)) * z_(i) / g_v(i);
            } 

        tauf = sigma_0 * z_ + sigma_1 * z_dot + sigma_2 * robot_state->dtheta;
        
        z_ = z_ + z_dot * dt;

        u+=tauf;
    }

    return u;
}


bool Controller::init_gravity_compensation()
{
    // do nothing..
    return true;
}

Eigen::VectorXd Controller::gravity_compensation()
{   
    Eigen::VectorXd control_motor_torque = robot_state->get_gravity(robot_state->q);
    return control_motor_torque;
}

bool Controller::init_contact_feedback_mpc()
{
    // initialize lpf
    const double lpf_opt_u_cutoff_freq = robot_state->get_config()["lpf_opt_u_cutoff_freq"].as<double>();
    if(opt_data->u0.size() != robot_state->nu)
    {   
        std::cout<<"ERROR: opt_data is not received"<<std::endl;
        return false;
    }
    const double time_elipse = (robot_state->time_now - opt_data->t0).seconds();
    if(time_elipse>0.005) // 200Hz
    {
        std::cout<<"ERROR: dt is too large"<<std::endl;
        return false;
    }
    
    lpf_opt_u.init(0.001, lpf_opt_u_cutoff_freq, opt_data->u0);
    return true;
}

Eigen::VectorXd Controller::contact_feedback_mpc()
{
    Eigen::VectorXd control_motor_torque(robot_state->nu);

    control_motor_torque = opt_data->u0;

    if(opt_data->use_approximation)
    {
        Eigen::VectorXd dx(robot_state->ndx);
        dx.head(robot_state->nv) = robot_state->difference(opt_data->x0.head(robot_state->nq), robot_state->q);
        dx.tail(robot_state->nv) = robot_state->dq - opt_data->x0.tail(robot_state->nv);

        control_motor_torque += opt_data->K * dx;
    }

    if(opt_data->use_lpf)
    {
        control_motor_torque = lpf_opt_u.get_filtered_value(control_motor_torque);
    }

    //calculate time difference opt_data->t0 and opt_data->t
    const double time_elipse = (robot_state->time_now - opt_data->t0).seconds();
    if(time_elipse > 0.01) //100Hz
    {
        std::cout<<"[CONTACT_FEEDBACK_MPC] dt is too large"<<std::endl;
        control_motor_torque.resize(1); // ERRIR signal
    }

    return control_motor_torque;
}

bool Controller::init_passive_contact_feedback_mpc()
{
    // initialize lpf
    const double lpf_opt_u_cutoff_freq = robot_state->get_config()["lpf_opt_u_cutoff_freq"].as<double>();
    if(opt_data->u0.size() != robot_state->nu)
    {   
        std::cout<<"ERROR: opt_data is not received"<<std::endl;
        return false;
    }
    const double time_elipse = (robot_state->time_now - opt_data->t0).seconds();
    if(time_elipse>0.005) // 200Hz
    {
        std::cout<<"ERROR: dt is too large"<<std::endl;
        return false;
    }
    
    lpf_opt_u.init(0.001, lpf_opt_u_cutoff_freq, opt_data->u0);
    const EnergyTankConfig tank_config = controller_gain.get_energy_tank_config();
    energy_tank.init(tank_config);
    energy_tank_data.init(tank_config);
    return true;
}

Eigen::VectorXd Controller::passive_contact_feedback_mpc()
{
    Eigen::VectorXd control_motor_torque(robot_state->nu);
    Eigen::VectorXd controller_output(robot_state->nu);
    const EnergyTankConfig & config = controller_gain.get_energy_tank_config();

    controller_output = opt_data->u0;

    // intergrate xt
    const double xt_next = energy_tank_data.xt +energy_tank_data.dxt * dt;

    // linear approximation of MPC output
    if(opt_data->use_approximation)
    {
        Eigen::VectorXd dx(robot_state->ndx);
        dx.head(robot_state->nv) = robot_state->difference(opt_data->x0.head(robot_state->nq), robot_state->q);
        dx(robot_state->nq+1) = opt_data->x0(robot_state->nq+1) - xt_next;
        dx.tail(robot_state->nv) = robot_state->dq - opt_data->x0.tail(robot_state->nv);

        controller_output += opt_data->K * dx;
    }

    // low-pass filtering
    if(opt_data->use_lpf)
    {
        controller_output = lpf_opt_u.get_filtered_value(controller_output);
    }

    energy_tank_data.update_data(xt_next, controller_output, robot_state->dq);

    energy_tank.calc(energy_tank_data);

    control_motor_torque = energy_tank_data.u - energy_tank_data.damping + robot_state->get_gravity(robot_state->q) ;

    //calculate time difference opt_data->t0 and opt_data->t
    const double time_elipse = (robot_state->time_now - opt_data->t0).seconds();
    if(time_elipse > config.mpc_run_out_time) 
    {
        std::cout<<"[CONTACT_FEEDBACK_MPC] dt is too large"<<std::endl;
        control_motor_torque.resize(1); // ERRIR signal
    }

    return control_motor_torque;
}

