#include <kinova_controller/controller/controller_gain.hpp>
ControllerGain::ControllerGain()
{

}

ControllerGain::~ControllerGain()
{

}

void ControllerGain::init(const YAML::Node& node)
{
    read_JOINT_PD_Gains(node);
    read_JOINT_NRIC_Gains(node);
    read_TASK_PD_Gains(node);
    read_TASK_NRIC_Gains(node);
    read_EnergyTankConfig(node);
    //CONTROLLER_CONFIG
    read_JOINT_FRIC_Gains(node);
}

void ControllerGain::print_matrix(const Eigen::MatrixXd& matrix, const std::string& name)
{
    std::cout<<name <<" ("<< matrix.cols() << "," << matrix.rows() << ")" << " : " << std::endl;
    std::cout<<matrix << std::endl;
}

void ControllerGain::read_JOINT_PD_Gains(const YAML::Node& node)
{
    //JOINT_PD_Gains
    try
    {
        const YAML::Node& joint_pd_gains_node = node["joint_pd_gains"];

        if (!joint_pd_gains_node.IsDefined() || joint_pd_gains_node.IsNull())
        {
            std::cout<<"joint_pd_gains is not defined or null" << std::endl;
        }
        else
        {
            std::vector<double> Kp_vec = joint_pd_gains_node["Kp"].as<std::vector<double>>();
            std::vector<double> Kd_vec = joint_pd_gains_node["Kd"].as<std::vector<double>>();
            joint_pd_gains_.Kp.resize(Kp_vec.size(),Kp_vec.size()); joint_pd_gains_.Kp.setZero();
            joint_pd_gains_.Kd.resize(Kd_vec.size(),Kd_vec.size()); joint_pd_gains_.Kd.setZero();
            joint_pd_gains_.Kp.diagonal() = Eigen::Map<Eigen::VectorXd>(Kp_vec.data(),Kp_vec.size());
            joint_pd_gains_.Kd.diagonal() = Eigen::Map<Eigen::VectorXd>(Kd_vec.data(),Kd_vec.size());

            const bool verbose = joint_pd_gains_node["verbose"].as<bool>();
            if(verbose)
            {   
                print_matrix(joint_pd_gains_.Kp,"joint_pd_gains_.Kp");
                print_matrix(joint_pd_gains_.Kd,"joint_pd_gains_.Kd");
            }            
        }
    }
    catch(const std::exception& e)
    {   
        std::cout<<"ERROR: joint_pd_gains are poorly defined in the yaml file" << std::endl;
        std::cerr << e.what() << '\n';
    }
}

void ControllerGain::read_JOINT_NRIC_Gains(const YAML::Node& node)
{
    //JOINT_PD_Gains
    try
    {
        const YAML::Node& joint_nric_gains_node = node["joint_nric_gains"];

        if (!joint_nric_gains_node.IsDefined() || joint_nric_gains_node.IsNull())
        {
            std::cout<<"joint_nric_gains_node is not defined or null" << std::endl;
        }
        else
        {
            std::vector<double> k1_vec = joint_nric_gains_node["k1"].as<std::vector<double>>();
            std::vector<double> k2_vec = joint_nric_gains_node["k2"].as<std::vector<double>>();
            std::vector<double> K_vec = joint_nric_gains_node["K"].as<std::vector<double>>();
            std::vector<double> gamma_vec = joint_nric_gains_node["gamma"].as<std::vector<double>>();
            std::vector<double> reflected_inertia_vec = joint_nric_gains_node["reflected_inertia"].as<std::vector<double>>();
            std::vector<double> Kp_vec = joint_nric_gains_node["Kp"].as<std::vector<double>>();            
            std::vector<double> Ki_vec = joint_nric_gains_node["Ki"].as<std::vector<double>>();

            joint_nric_gains_.k1.resize(k1_vec.size(),k1_vec.size()); joint_nric_gains_.k1.setZero();
            joint_nric_gains_.k2.resize(k2_vec.size(),k2_vec.size()); joint_nric_gains_.k2.setZero();
            joint_nric_gains_.K.resize(K_vec.size(),K_vec.size()); joint_nric_gains_.K.setZero();
            joint_nric_gains_.gamma.resize(gamma_vec.size(),gamma_vec.size()); joint_nric_gains_.gamma.setZero();
            joint_nric_gains_.reflected_inertia.resize(reflected_inertia_vec.size(),reflected_inertia_vec.size()); joint_nric_gains_.reflected_inertia.setZero();
            joint_nric_gains_.Kp.resize(Kp_vec.size(),Kp_vec.size()); joint_nric_gains_.Kp.setZero();            
            joint_nric_gains_.Ki.resize(Ki_vec.size(),Ki_vec.size()); joint_nric_gains_.Ki.setZero();

            joint_nric_gains_.k1.diagonal() = Eigen::Map<Eigen::VectorXd>(k1_vec.data(),k1_vec.size());
            joint_nric_gains_.k2.diagonal() = Eigen::Map<Eigen::VectorXd>(k2_vec.data(),k2_vec.size());
            joint_nric_gains_.K.diagonal() = Eigen::Map<Eigen::VectorXd>(K_vec.data(),K_vec.size());
            joint_nric_gains_.gamma.diagonal() = Eigen::Map<Eigen::VectorXd>(gamma_vec.data(),gamma_vec.size());
            joint_nric_gains_.reflected_inertia.diagonal() = Eigen::Map<Eigen::VectorXd>(reflected_inertia_vec.data(),reflected_inertia_vec.size());
            joint_nric_gains_.Kp.diagonal() = Eigen::Map<Eigen::VectorXd>(Kp_vec.data(),Kp_vec.size());            
            joint_nric_gains_.Ki.diagonal() = Eigen::Map<Eigen::VectorXd>(Ki_vec.data(),Ki_vec.size());


            const bool verbose = joint_nric_gains_node["verbose"].as<bool>();
            if(verbose)
            {
                print_matrix(joint_nric_gains_.k1,"joint_nric_gains_.k1");
                print_matrix(joint_nric_gains_.k2,"joint_nric_gains_.k2");
                print_matrix(joint_nric_gains_.K,"joint_nric_gains_.K");
                print_matrix(joint_nric_gains_.gamma,"joint_nric_gains_.gamma");
                print_matrix(joint_nric_gains_.reflected_inertia,"joint_nric_gains_.reflected_inertia");
                print_matrix(joint_nric_gains_.Kp,"joint_nric_gains_.Kp");
                print_matrix(joint_nric_gains_.Ki,"joint_nric_gains_.Ki");
            }            
        }
    }
    catch(const std::exception& e)
    {
        std::cout<<"ERROR: joint_nric_gains are poorly defined in the yaml file" << std::endl;
        std::cerr << e.what() << '\n';  
    }
}

void ControllerGain::read_TASK_PD_Gains(const YAML::Node& node)
{
    //JOINT_PD_Gains
    try
    {
        const YAML::Node& task_pd_gains_node = node["task_pd_gains"];

        if (!task_pd_gains_node.IsDefined() || task_pd_gains_node.IsNull())
        {
            std::cout<<"task_pd_gains is not defined or null" << std::endl;
        }
        else
        {
            std::vector<double> Kp_vec = task_pd_gains_node["Kp"].as<std::vector<double>>();
            std::vector<double> Kd_vec = task_pd_gains_node["Kd"].as<std::vector<double>>();
            task_pd_gains_.Kp.resize(Kp_vec.size(),Kp_vec.size()); task_pd_gains_.Kp.setZero();
            task_pd_gains_.Kd.resize(Kd_vec.size(),Kd_vec.size()); task_pd_gains_.Kd.setZero();
            task_pd_gains_.Kp.diagonal() = Eigen::Map<Eigen::VectorXd>(Kp_vec.data(),Kp_vec.size());
            task_pd_gains_.Kd.diagonal() = Eigen::Map<Eigen::VectorXd>(Kd_vec.data(),Kd_vec.size());

            const bool verbose = task_pd_gains_node["verbose"].as<bool>();
            if(verbose)
            {
                print_matrix(task_pd_gains_.Kp,"task_pd_gains_.Kp");
                print_matrix(task_pd_gains_.Kd,"task_pd_gains_.Kd");
            }            
        }
    }
    catch(const std::exception& e)
    {   
        std::cout<<"ERROR: task_pd_gains are poorly defined in the yaml file" << std::endl;
        std::cerr << e.what() << '\n';
    }
}

void ControllerGain::read_TASK_NRIC_Gains(const YAML::Node& node)
{
    //JOINT_PD_Gains
    try
    {
        const YAML::Node& task_nric_gains_node = node["task_nric_gains"];

        if (!task_nric_gains_node.IsDefined() || task_nric_gains_node.IsNull())
        {
            std::cout<<"task_nric_gains_node is not defined or null" << std::endl;
        }
        else
        {
            std::vector<double> k1_vec = task_nric_gains_node["k1"].as<std::vector<double>>();
            std::vector<double> k2_vec = task_nric_gains_node["k2"].as<std::vector<double>>();
            std::vector<double> K_vec = task_nric_gains_node["K"].as<std::vector<double>>();
            std::vector<double> gamma_vec = task_nric_gains_node["gamma"].as<std::vector<double>>();
            std::vector<double> reflected_inertia_vec = task_nric_gains_node["reflected_inertia"].as<std::vector<double>>();
            std::vector<double> Kp_vec = task_nric_gains_node["Kp"].as<std::vector<double>>();            
            std::vector<double> Ki_vec = task_nric_gains_node["Ki"].as<std::vector<double>>();

            task_nric_gains_.k1.resize(k1_vec.size(),k1_vec.size()); task_nric_gains_.k1.setZero();
            task_nric_gains_.k2.resize(k2_vec.size(),k2_vec.size()); task_nric_gains_.k2.setZero();
            task_nric_gains_.K.resize(K_vec.size(),K_vec.size()); task_nric_gains_.K.setZero();
            task_nric_gains_.gamma.resize(gamma_vec.size(),gamma_vec.size()); task_nric_gains_.gamma.setZero();
            task_nric_gains_.reflected_inertia.resize(reflected_inertia_vec.size(),reflected_inertia_vec.size()); task_nric_gains_.reflected_inertia.setZero();
            task_nric_gains_.Kp.resize(Kp_vec.size(),Kp_vec.size()); task_nric_gains_.Kp.setZero();            
            task_nric_gains_.Ki.resize(Ki_vec.size(),Ki_vec.size()); task_nric_gains_.Ki.setZero();

            task_nric_gains_.k1.diagonal() = Eigen::Map<Eigen::VectorXd>(k1_vec.data(),k1_vec.size());
            task_nric_gains_.k2.diagonal() = Eigen::Map<Eigen::VectorXd>(k2_vec.data(),k2_vec.size());
            task_nric_gains_.K.diagonal() = Eigen::Map<Eigen::VectorXd>(K_vec.data(),K_vec.size());
            task_nric_gains_.gamma.diagonal() = Eigen::Map<Eigen::VectorXd>(gamma_vec.data(),gamma_vec.size());
            task_nric_gains_.reflected_inertia.diagonal() = Eigen::Map<Eigen::VectorXd>(reflected_inertia_vec.data(),reflected_inertia_vec.size());
            task_nric_gains_.Kp.diagonal() = Eigen::Map<Eigen::VectorXd>(Kp_vec.data(),Kp_vec.size());            
            task_nric_gains_.Ki.diagonal() = Eigen::Map<Eigen::VectorXd>(Ki_vec.data(),Ki_vec.size());


            const bool verbose = task_nric_gains_node["verbose"].as<bool>();
            if(verbose)
            {
                print_matrix(task_nric_gains_.k1,"task_nric_gains_.k1");
                print_matrix(task_nric_gains_.k2,"task_nric_gains_.k2");
                print_matrix(task_nric_gains_.K,"task_nric_gains_.K");
                print_matrix(task_nric_gains_.gamma,"task_nric_gains_.gamma");
                print_matrix(task_nric_gains_.reflected_inertia,"task_nric_gains_.reflected_inertia");
                print_matrix(task_nric_gains_.Kp,"task_nric_gains_.Kp");
                print_matrix(task_nric_gains_.Ki,"task_nric_gains_.Ki");

            }            
        }
    }
    catch(const std::exception& e)
    {
        std::cout<<"ERROR: joint_nric_gains are poorly defined in the yaml file" << std::endl;
        std::cerr << e.what() << '\n';  
    }
}

void ControllerGain::read_EnergyTankConfig(const YAML::Node& node)
{
    try
    {
        const YAML::Node& energy_tank_config_node = node["energy_tank_config"];

        if (!energy_tank_config_node.IsDefined() || energy_tank_config_node.IsNull())
        {
            std::cout<<"energy_tank_config is not defined or null" << std::endl;
        }
        else
        {
            energy_tank_config_.initial_energy = energy_tank_config_node["initial_energy"].as<double>(); 
            energy_tank_config_.max_energy = energy_tank_config_node["max_energy"].as<double>();
            energy_tank_config_.min_energy = energy_tank_config_node["min_energy"].as<double>();
            std::vector<double> Kd_vec = energy_tank_config_node["Kd"].as<std::vector<double>>();
            energy_tank_config_.Kd.resize(Kd_vec.size(),Kd_vec.size()); energy_tank_config_.Kd.setZero();
            energy_tank_config_.Kd.diagonal() = Eigen::Map<Eigen::VectorXd>(Kd_vec.data(),Kd_vec.size());
            energy_tank_config_.mpc_run_out_time = energy_tank_config_node["mpc_run_out_time"].as<double>();

            const bool verbose = energy_tank_config_node["verbose"].as<bool>();
            if(verbose)
            {
                std::cout<<"energy_tank_config_.initial_energy: "<<energy_tank_config_.initial_energy<<std::endl;
                std::cout<<"energy_tank_config_.max_energy: "<<energy_tank_config_.max_energy<<std::endl;
                std::cout<<"energy_tank_config_.min_energy: "<<energy_tank_config_.min_energy<<std::endl;
                std::cout<<"energy_tank_config_.mpc_run_out_time: "<<energy_tank_config_.mpc_run_out_time<<std::endl;
                print_matrix(energy_tank_config_.Kd,"energy_tank_config_.Kd");
            }            
        }
    }
    catch(const std::exception& e)
    {
        std::cout<<"ERROR: energy_tank_config are poorly defined in the yaml file" << std::endl;
        std::cerr << e.what() << '\n';  
    }
}

//CONTROLLER_CONFIG
void ControllerGain::read_JOINT_FRIC_Gains(const YAML::Node& node)
{
    try
    {
        const YAML::Node& joint_fric_gains_node = node["joint_fric_gains"];

        if (!joint_fric_gains_node.IsDefined() || joint_fric_gains_node.IsNull())
        {
            std::cout<<"joint_fric_gains_node is not defined or null" << std::endl;
        }
        else
        {
            std::vector<double> Kp_vec = joint_fric_gains_node["Kp"].as<std::vector<double>>();
            std::vector<double> Kd_vec = joint_fric_gains_node["Kp"].as<std::vector<double>>();
            std::vector<double> L_vec = joint_fric_gains_node["L"].as<std::vector<double>>();
            std::vector<double> Lp_vec = joint_fric_gains_node["Lp"].as<std::vector<double>>();
            std::vector<double> motor_inertia_vec = joint_fric_gains_node["motor_inertia_matrix"].as<std::vector<double>>();
            std::vector<double> joint_stiffness_vec = joint_fric_gains_node["joint_stiffness_matrix"].as<std::vector<double>>();            

            joint_fric_gains_.Kp.resize(Kp_vec.size(),Kp_vec.size()); joint_fric_gains_.Kp.setZero();
            joint_fric_gains_.Kd.resize(Kd_vec.size(),Kd_vec.size()); joint_fric_gains_.Kd.setZero();
            joint_fric_gains_.L.resize(L_vec.size(),L_vec.size()); joint_fric_gains_.L.setZero();
            joint_fric_gains_.Lp.resize(Lp_vec.size(),Lp_vec.size()); joint_fric_gains_.Lp.setZero();
            joint_fric_gains_.motor_inertia_matrix.resize(motor_inertia_vec.size(),motor_inertia_vec.size()); joint_fric_gains_.motor_inertia_matrix.setZero();
            joint_fric_gains_.joint_stiffness_matrix.resize(joint_stiffness_vec.size(),joint_stiffness_vec.size()); joint_fric_gains_.joint_stiffness_matrix.setZero();            

            joint_fric_gains_.Kp.diagonal() = Eigen::Map<Eigen::VectorXd>(Kp_vec.data(),Kp_vec.size());
            joint_fric_gains_.Kd.diagonal() = Eigen::Map<Eigen::VectorXd>(Kd_vec.data(),Kd_vec.size());
            joint_fric_gains_.L.diagonal() = Eigen::Map<Eigen::VectorXd>(L_vec.data(),L_vec.size());
            joint_fric_gains_.Lp.diagonal() = Eigen::Map<Eigen::VectorXd>(Lp_vec.data(),Lp_vec.size());
            joint_fric_gains_.motor_inertia_matrix.diagonal() = Eigen::Map<Eigen::VectorXd>(motor_inertia_vec.data(),motor_inertia_vec.size());
            joint_fric_gains_.joint_stiffness_matrix.diagonal() = Eigen::Map<Eigen::VectorXd>(joint_stiffness_vec.data(),joint_stiffness_vec.size());            


            const bool verbose = joint_fric_gains_node["verbose"].as<bool>();
            if(verbose)
            {
                print_matrix(joint_fric_gains_.Kp,"joint_fric_gains_.Kp");
                print_matrix(joint_fric_gains_.Kd,"joint_fric_gains_.KP");
                print_matrix(joint_fric_gains_.L,"joint_fric_gains_.L");
                print_matrix(joint_fric_gains_.Lp,"joint_fric_gains_.Lp");
                print_matrix(joint_fric_gains_.motor_inertia_matrix,"joint_fric_gains_.motor_inertia_matrix");
                print_matrix(joint_fric_gains_.joint_stiffness_matrix,"joint_fric_gains_.joint_stiffness_matrix");
            }            
        }
    }
    catch(const std::exception& e)
    {
        std::cout<<"ERROR: joint_fric_gains are poorly defined in the yaml file" << std::endl;
        std::cerr << e.what() << '\n';  
    }
}