#include "kinova_controller/energy_tank/energy_tank_base.hpp"

EnergyTankBase::EnergyTankBase()
{
    //do nothing
}
